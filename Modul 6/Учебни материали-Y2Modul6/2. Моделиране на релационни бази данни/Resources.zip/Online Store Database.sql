-- Online Store Database
CREATE DATABASE `online_store`;

USE `online_store`;

CREATE TABLE `cities`(
	`city_id` int,
	`name` varchar(50),
  CONSTRAINT `pk_cities` PRIMARY KEY (`city_id`)
 );

CREATE TABLE `customers`(
	`customer_id` int,
	`name` varchar(50),
	`birthday` date,
	`city_id` int,
  CONSTRAINT `pk_customers` PRIMARY KEY(`customer_id`)
 );

CREATE TABLE `items`(
	`item_id` int,
	`name` varchar(50),
	`item_type_id` int,
  CONSTRAINT `pk_items` PRIMARY KEY (`item_id`)
);

CREATE TABLE `item_types`(
	`item_type_id` int,
	`name` varchar(50),
  CONSTRAINT `pk_item_types` PRIMARY KEY (`item_type_id`)
 );

CREATE TABLE `order_items`(
	`order_id` int,
	`item_id` int,
  CONSTRAINT `pk_order_items` PRIMARY KEY (`order_id`,`item_id`)
 );

CREATE TABLE `orders`(
	`order_id` int,
	`customer_id` int,
  CONSTRAINT `pk_orders` PRIMARY KEY (`order_id`)
);

ALTER TABLE `customers` ADD CONSTRAINT `fk_customers_cities` FOREIGN KEY(`city_id`)
REFERENCES `cities` (`city_id`);

ALTER TABLE `items` ADD CONSTRAINT `fk_items_item_types` FOREIGN KEY(`item_type_id`)
REFERENCES `item_types` (`item_type_id`);

ALTER TABLE `order_items` ADD CONSTRAINT `fk_order_items_items` FOREIGN KEY(`item_id`)
REFERENCES `items` (`item_id`);

ALTER TABLE `order_items`  ADD CONSTRAINT `fk_order_items_orders` FOREIGN KEY(`order_id`)
REFERENCES `orders` (`order_id`);

ALTER TABLE `orders` ADD CONSTRAINT `fk_orders_customers` FOREIGN KEY(`customer_id`)
REFERENCES `customers` (`customer_id`);

-- test 1 : 'orders' table name, column names, column types and PK check
SELECT lower(table_name)
FROM information_schema.TABLES 
WHERE TABLE_SCHEMA = database() and lower(TABLE_NAME) = 'orders';
SELECT lower(COLUMN_NAME), lower(COLUMN_TYPE)
FROM information_schema.COLUMNS 
WHERE TABLE_SCHEMA = database() and lower(TABLE_NAME) = 'orders';

SELECT COLUMN_NAME AS pk_count
FROM information_schema.COLUMNS
WHERE TABLE_SCHEMA = DATABASE() AND COLUMN_KEY = 'PRI' AND TABLE_NAME IN ('orders');
   
-- test 2 : 'customers' table name, column names, column types and PK check
SELECT lower(table_name)
FROM information_schema.TABLES 
WHERE TABLE_SCHEMA = database() and lower(TABLE_NAME) = 'customers';
SELECT lower(COLUMN_NAME), lower(COLUMN_TYPE)
FROM information_schema.COLUMNS 
WHERE TABLE_SCHEMA = database() and lower(TABLE_NAME) = 'customers';

SELECT COLUMN_NAME
FROM information_schema.COLUMNS
WHERE TABLE_SCHEMA = database() AND COLUMN_KEY = 'PRI' AND TABLE_NAME = 'customers';
   
-- test 3 : 'cities' table name, column names, column types and PK check
SELECT lower(table_name)	 
FROM information_schema.TABLES 
WHERE TABLE_SCHEMA = database() and lower(TABLE_NAME) = 'cities';
SELECT lower(COLUMN_NAME), lower(COLUMN_TYPE)
FROM information_schema.COLUMNS 
WHERE TABLE_SCHEMA = database() and lower(TABLE_NAME) = 'cities';

SELECT COLUMN_NAME
FROM information_schema.COLUMNS
WHERE TABLE_SCHEMA = database() AND COLUMN_KEY = 'PRI' AND TABLE_NAME = 'cities';
   
-- test 4 : 'items' table name, column names, column types and PK check
SELECT lower(table_name)
FROM information_schema.TABLES 
WHERE TABLE_SCHEMA = database() and lower(TABLE_NAME) = 'items';
SELECT lower(COLUMN_NAME), lower(COLUMN_TYPE)
FROM information_schema.COLUMNS 
WHERE TABLE_SCHEMA = database() and lower(TABLE_NAME) = 'items';

SELECT COLUMN_NAME
FROM information_schema.COLUMNS
WHERE TABLE_SCHEMA = database() AND COLUMN_KEY = 'PRI' AND TABLE_NAME = 'items';
   
-- test 5 : 'item_types' table name, column names, column types and PK check
SELECT lower(table_name)
FROM information_schema.TABLES 
WHERE TABLE_SCHEMA = database() and lower(TABLE_NAME) = 'item_types';
SELECT lower(COLUMN_NAME), lower(COLUMN_TYPE)
FROM information_schema.COLUMNS 
WHERE TABLE_SCHEMA = database() and lower(TABLE_NAME) = 'item_types';

SELECT COLUMN_NAME
FROM information_schema.COLUMNS
WHERE TABLE_SCHEMA = database() AND COLUMN_KEY = 'PRI' AND TABLE_NAME = 'item_types';
   
-- test 6 : 'order_items' table name, column names, column types and PK check
SELECT lower(table_name)
FROM information_schema.TABLES 
WHERE TABLE_SCHEMA = database() and lower(TABLE_NAME) = 'order_items';
SELECT lower(COLUMN_NAME), lower(COLUMN_TYPE)
FROM information_schema.COLUMNS 
WHERE TABLE_SCHEMA = database() and lower(TABLE_NAME) = 'order_items';

SELECT COLUMN_NAME
FROM information_schema.COLUMNS
WHERE TABLE_SCHEMA = database() AND COLUMN_KEY = 'PRI' AND TABLE_NAME = 'order_items';
   
-- test 7 : fk_customers_cities check
SELECT lower(TABLE_NAME) tn,lower(COLUMN_NAME) cn, lower(REFERENCED_TABLE_NAME) ref_tn,lower(REFERENCED_COLUMN_NAME) ref_cn
FROM INFORMATION_SCHEMA.KEY_COLUMN_USAGE
WHERE REFERENCED_TABLE_SCHEMA = database() AND
  lower(REFERENCED_COLUMN_NAME) = 'city_id' AND 
  lower(REFERENCED_TABLE_NAME) = 'cities';
  
-- test 8 : fk_items_item_types check
SELECT lower(TABLE_NAME) tn,lower(COLUMN_NAME) cn, lower(REFERENCED_TABLE_NAME) ref_tn,lower(REFERENCED_COLUMN_NAME) ref_cn
FROM INFORMATION_SCHEMA.KEY_COLUMN_USAGE
WHERE REFERENCED_TABLE_SCHEMA = database() AND
  lower(REFERENCED_COLUMN_NAME) = 'item_type_id' AND 
  lower(REFERENCED_TABLE_NAME) = 'item_types';
  
-- test 9 : fk_order_items_items check
SELECT lower(TABLE_NAME) tn,lower(COLUMN_NAME) cn, lower(REFERENCED_TABLE_NAME) ref_tn,lower(REFERENCED_COLUMN_NAME) ref_cn
FROM INFORMATION_SCHEMA.KEY_COLUMN_USAGE
WHERE REFERENCED_TABLE_SCHEMA = database() AND
  lower(REFERENCED_COLUMN_NAME) = 'item_id' AND 
  lower(REFERENCED_TABLE_NAME) = 'items';
  
-- test 10 : fk_order_items_orders check
SELECT lower(TABLE_NAME) tn,lower(COLUMN_NAME) cn, lower(REFERENCED_TABLE_NAME) ref_tn,lower(REFERENCED_COLUMN_NAME) ref_cn
FROM INFORMATION_SCHEMA.KEY_COLUMN_USAGE
WHERE REFERENCED_TABLE_SCHEMA = database() AND
  lower(REFERENCED_COLUMN_NAME) = 'order_id' AND 
  lower(REFERENCED_TABLE_NAME) = 'orders';
  
-- test 11 : fk_orders_customers check
SELECT lower(TABLE_NAME) tn,lower(COLUMN_NAME) cn, lower(REFERENCED_TABLE_NAME) ref_tn,lower(REFERENCED_COLUMN_NAME) ref_cn
FROM INFORMATION_SCHEMA.KEY_COLUMN_USAGE
WHERE REFERENCED_TABLE_SCHEMA = database() AND
  lower(REFERENCED_COLUMN_NAME) = 'customer_id' AND 
  lower(REFERENCED_TABLE_NAME) = 'customers';
