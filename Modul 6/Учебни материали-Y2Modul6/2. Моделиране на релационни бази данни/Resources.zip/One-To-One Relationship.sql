-- One-To-One Relationship 
CREATE TABLE `passports`(
  `passport_id` INT PRIMARY KEY,
  `passport_number` VARCHAR(50)
);

CREATE TABLE `persons`(
  `person_id` INT PRIMARY KEY,
  `first_name` VARCHAR(50),
  `salary` DECIMAL(8,2),
  `passport_id` INT UNIQUE,
  CONSTRAINT `fk_persons_passports` FOREIGN KEY(`passport_id`) REFERENCES `passports`(`passport_id`)
);

INSERT INTO `passports`(`passport_id`, `passport_number`)
VALUES
(101, 'N34FG21B'),
(102, 'K65LO4R7'),
(103, 'ZE657QP2');

INSERT INTO `persons`(`person_id`, `first_name`, `salary`, `passport_id`)
VALUES
(1, 'Roberto', 43300.00, 102),
(2, 'Tom', 56100.00, 103),
(3, 'Yana', 60200.00, 101);

-- table persons name and column names check
SELECT lower(table_name)
FROM information_schema.TABLES 
WHERE TABLE_SCHEMA = database() and lower(TABLE_NAME) = 'persons';
SELECT lower(COLUMN_NAME) 
FROM information_schema.COLUMNS 
WHERE TABLE_SCHEMA = database() and lower(TABLE_NAME) = 'persons';

-- table passports name and column names check
SELECT lower(table_name)
FROM information_schema.TABLES 
WHERE TABLE_SCHEMA = database() and lower(TABLE_NAME) = 'passports';
SELECT lower(COLUMN_NAME) 
FROM information_schema.COLUMNS 
WHERE TABLE_SCHEMA = database() and lower(TABLE_NAME) = 'passports';
   
-- primary keys check
SELECT TABLE_NAME, COUNT(*) AS pk_count
FROM information_schema.COLUMNS
WHERE TABLE_SCHEMA = DATABASE() AND COLUMN_KEY = 'PRI' AND TABLE_NAME IN ('passports', 'persons')
GROUP BY TABLE_NAME
ORDER BY TABLE_NAME;
 
-- check if persons.passport_id has unique constraint
SELECT lower(column_name)
FROM INFORMATION_SCHEMA.columns
WHERE TABLE_SCHEMA = database() AND lower(table_name) = 'persons' AND column_name = 'passport_id' AND column_key = 'UNI';

-- foreign key check
SELECT lower(TABLE_NAME) tn,lower(COLUMN_NAME) cn, lower(REFERENCED_TABLE_NAME) ref_tn,lower(REFERENCED_COLUMN_NAME) ref_cn
FROM INFORMATION_SCHEMA.KEY_COLUMN_USAGE
WHERE REFERENCED_TABLE_SCHEMA = database() AND
  lower(REFERENCED_COLUMN_NAME) = 'passport_id' AND 
  lower(REFERENCED_TABLE_NAME) = 'passports';
 
-- data insertion check
SELECT * 
FROM `persons` AS `per` 
INNER JOIN `passports` AS `pas` ON `per`.`passport_id` = `pas`.`passport_id`
ORDER BY `per`.`person_id`; 