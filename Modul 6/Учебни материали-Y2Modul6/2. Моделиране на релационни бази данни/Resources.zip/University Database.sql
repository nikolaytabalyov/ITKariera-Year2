-- University Database
CREATE TABLE `majors`(
  `major_id` INT PRIMARY KEY,
  `name` VARCHAR(50)
);

CREATE TABLE `students`(
  `student_id` INT PRIMARY KEY,
  `student_number` VARCHAR(12),
  `student_name` VARCHAR(50),
  `major_id` INT,
  CONSTRAINT `fk_students_majors` FOREIGN KEY(`major_id`) REFERENCES `majors`(`major_id`)
);

CREATE TABLE `payments`(
  `payment_id` INT PRIMARY KEY, 
  `payment_date` DATE,
  `payment_amount` DECIMAL(8,2),
  `student_id` INT,
  CONSTRAINT `fk_payments_students` FOREIGN KEY (`student_id`) REFERENCES `students`(`student_id`)
);

CREATE TABLE `subjects`(
  `subject_id` INT PRIMARY KEY,
  `subject_name` VARCHAR(50)
);

CREATE TABLE `agenda`(
  `student_id` INT,
  `subject_id` INT,
  CONSTRAINT `pk_agenda` PRIMARY KEY(`student_id`, `subject_id`),
  CONSTRAINT `fk_agenda_subjects` FOREIGN KEY(`subject_id`) REFERENCES `subjects`(`subject_id`),
  CONSTRAINT `fk_agenda_students` FOREIGN KEY(`student_id`) REFERENCES `students`(`student_id`)
);

--- test 1 : 'majors' table name, column names, column types and PK check
SELECT lower(table_name)
FROM information_schema.TABLES 
WHERE TABLE_SCHEMA = database() and lower(TABLE_NAME) = 'majors';
SELECT lower(COLUMN_NAME), lower(COLUMN_TYPE)
FROM information_schema.COLUMNS 
WHERE TABLE_SCHEMA = database() and lower(TABLE_NAME) = 'majors';

SELECT COLUMN_NAME AS pk_count
FROM information_schema.COLUMNS
WHERE TABLE_SCHEMA = DATABASE() AND COLUMN_KEY = 'PRI' AND TABLE_NAME IN ('majors');
   
-- test 2 : 'students' table name, column names, column types and PK check
SELECT lower(table_name)
FROM information_schema.TABLES 
WHERE TABLE_SCHEMA = database() and lower(TABLE_NAME) = 'students';
SELECT lower(COLUMN_NAME), lower(COLUMN_TYPE)
FROM information_schema.COLUMNS 
WHERE TABLE_SCHEMA = database() and lower(TABLE_NAME) = 'students';

SELECT COLUMN_NAME
FROM information_schema.COLUMNS
WHERE TABLE_SCHEMA = database() AND COLUMN_KEY = 'PRI' AND TABLE_NAME = 'students';
   
-- test 3 : 'payments' table name, column names, column types and PK check
SELECT lower(table_name)
FROM information_schema.TABLES 
WHERE TABLE_SCHEMA = database() and lower(TABLE_NAME) = 'payments';
SELECT lower(COLUMN_NAME), lower(COLUMN_TYPE)
FROM information_schema.COLUMNS 
WHERE TABLE_SCHEMA = database() and lower(TABLE_NAME) = 'payments';

SELECT COLUMN_NAME
FROM information_schema.COLUMNS
WHERE TABLE_SCHEMA = database() AND COLUMN_KEY = 'PRI' AND TABLE_NAME = 'payments';
   
-- test 4 : 'subjects' table name, column names, column types and PK check
SELECT lower(table_name)
FROM information_schema.TABLES 
WHERE TABLE_SCHEMA = database() and lower(TABLE_NAME) = 'subjects';
SELECT lower(COLUMN_NAME), lower(COLUMN_TYPE)
FROM information_schema.COLUMNS 
WHERE TABLE_SCHEMA = database() and lower(TABLE_NAME) = 'subjects';

SELECT COLUMN_NAME
FROM information_schema.COLUMNS
WHERE TABLE_SCHEMA = database() AND COLUMN_KEY = 'PRI' AND TABLE_NAME = 'subjects';
   
-- test 5: 'agenda' table name, column names, column types and PK check
SELECT lower(table_name)
FROM information_schema.TABLES 
WHERE TABLE_SCHEMA = database() and lower(TABLE_NAME) = 'agenda';
SELECT lower(COLUMN_NAME), lower(COLUMN_TYPE)
FROM information_schema.COLUMNS 
WHERE TABLE_SCHEMA = database() and lower(TABLE_NAME) = 'agenda';

SELECT COLUMN_NAME
FROM information_schema.COLUMNS
WHERE TABLE_SCHEMA = database() AND COLUMN_KEY = 'PRI' AND TABLE_NAME = 'agenda';
   
-- test 6: fk_students_majors check
SELECT lower(TABLE_NAME) tn,lower(COLUMN_NAME) cn, lower(REFERENCED_TABLE_NAME) ref_tn,lower(REFERENCED_COLUMN_NAME) ref_cn
FROM INFORMATION_SCHEMA.KEY_COLUMN_USAGE
WHERE REFERENCED_TABLE_SCHEMA = database() AND
  lower(REFERENCED_COLUMN_NAME) = 'major_id' AND 
  lower(REFERENCED_TABLE_NAME) = 'majors';
  
-- test 7: fk_payment_students check
SELECT lower(TABLE_NAME) tn,lower(COLUMN_NAME) cn, lower(REFERENCED_TABLE_NAME) ref_tn,lower(REFERENCED_COLUMN_NAME) ref_cn
FROM INFORMATION_SCHEMA.KEY_COLUMN_USAGE
WHERE REFERENCED_TABLE_SCHEMA = database() AND
  lower(TABLE_NAME) = 'payments' AND
  lower(REFERENCED_COLUMN_NAME) = 'student_id' AND 
  lower(REFERENCED_TABLE_NAME) = 'students';
    
-- test 8 : fk_agenda_subjects check
SELECT lower(TABLE_NAME) tn,lower(COLUMN_NAME) cn, lower(REFERENCED_TABLE_NAME) ref_tn,lower(REFERENCED_COLUMN_NAME) ref_cn
FROM INFORMATION_SCHEMA.KEY_COLUMN_USAGE
WHERE REFERENCED_TABLE_SCHEMA = database() AND
  lower(REFERENCED_COLUMN_NAME) = 'subject_id' AND 
  lower(REFERENCED_TABLE_NAME) = 'subjects';
  
-- test 9 : fk_agenda_students check
SELECT lower(TABLE_NAME) tn,lower(COLUMN_NAME) cn, lower(REFERENCED_TABLE_NAME) ref_tn,lower(REFERENCED_COLUMN_NAME) ref_cn
FROM INFORMATION_SCHEMA.KEY_COLUMN_USAGE
WHERE REFERENCED_TABLE_SCHEMA = database() AND
  lower(TABLE_NAME) = 'agenda' AND
  lower(REFERENCED_COLUMN_NAME) = 'student_id' AND 
  lower(REFERENCED_TABLE_NAME) = 'students';
