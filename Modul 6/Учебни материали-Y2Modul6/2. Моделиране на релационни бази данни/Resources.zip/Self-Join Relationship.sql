-- Self-Join Relationship 
CREATE TABLE `teachers`(
  `teacher_id` INT PRIMARY KEY,
  `name` VARCHAR(50),
  `manager_id` INT
);

INSERT INTO `teachers`(`teacher_id`, `name`, `manager_id`)
VALUES
(101, 'John', NULL),
(102, 'Maya', 106),
(103, 'Silvia', 106),
(104, 'Ted', 105),
(105, 'Mark', 101),
(106, 'Greta', 101);

ALTER TABLE `teachers`
ADD CONSTRAINT `fk_teachers_teachers` FOREIGN KEY(`manager_id`) REFERENCES `teachers`(`teacher_id`);

-- test 1 : 'teachers' table name
SELECT lower(table_name)
FROM information_schema.TABLES 
WHERE TABLE_SCHEMA = database() and lower(TABLE_NAME) = 'teachers';

-- test 2 : 'teachers' column names
SELECT lower(COLUMN_NAME) 
FROM information_schema.COLUMNS 
WHERE TABLE_SCHEMA = database() and lower(TABLE_NAME) = 'teachers';

-- test 3 : table teachers PK check
SELECT COLUMN_NAME AS pk_count
FROM information_schema.COLUMNS
WHERE TABLE_SCHEMA = DATABASE() AND COLUMN_KEY = 'PRI' AND TABLE_NAME IN ('teachers');
   
-- FK check
SELECT lower(TABLE_NAME) tn,lower(COLUMN_NAME) cn, lower(REFERENCED_TABLE_NAME) ref_tn,lower(REFERENCED_COLUMN_NAME) ref_cn
FROM INFORMATION_SCHEMA.KEY_COLUMN_USAGE
WHERE REFERENCED_TABLE_SCHEMA = database() AND lower(REFERENCED_COLUMN_NAME) = 'teacher_id' AND  lower(REFERENCED_TABLE_NAME) = 'teachers';
  
-- test 5 : data check
SELECT * 
FROM `teachers` 
ORDER BY `teacher_id`;