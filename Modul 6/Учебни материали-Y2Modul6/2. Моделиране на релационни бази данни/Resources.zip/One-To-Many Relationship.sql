-- One-To-Many Relationship
CREATE TABLE `manufacturers`(
  `manufacturer_id` INT PRIMARY KEY,
  `name` VARCHAR(50),
  `established_on` DATE
);

CREATE TABLE `models`(
  `model_id` INT PRIMARY KEY,
  `name` VARCHAR(50),
  `manufacturer_id` INT,
  CONSTRAINT `fk_models_manufacturer` FOREIGN KEY(`manufacturer_id`) REFERENCES `manufacturers`(`manufacturer_id`)
);

INSERT INTO `manufacturers` (`manufacturer_id`, `name`, `established_on`)
VALUES
(1, 'BMW', '19160301'),
(2, 'Tesla', '20030101'),
(3, 'Lada', '19660501');

INSERT INTO `models`(`model_id`, `name`, `manufacturer_id`)
VALUES
(101, 'X1', 1),
(102, 'i6', 1),
(103, 'Model S', 2),
(104, 'Model X', 2),
(105, 'Model 3', 2),
(106, 'Nova', 3);

-- table names and column names check
SELECT lower(table_name)
FROM information_schema.TABLES 
WHERE TABLE_SCHEMA = database() and lower(TABLE_NAME) = 'manufacturers';
SELECT lower(COLUMN_NAME) 
FROM information_schema.COLUMNS 
WHERE TABLE_SCHEMA = database() and lower(TABLE_NAME) = 'manufacturers';

SELECT lower(table_name)
FROM information_schema.TABLES 
WHERE TABLE_SCHEMA = database() and lower(TABLE_NAME) = 'models';
SELECT lower(COLUMN_NAME) 
FROM information_schema.COLUMNS 
WHERE TABLE_SCHEMA = database() and lower(TABLE_NAME) = 'models';
   
-- primary keys check
SELECT TABLE_NAME, COUNT(*) AS pk_count
FROM information_schema.COLUMNS
WHERE TABLE_SCHEMA = DATABASE() AND COLUMN_KEY = 'PRI' AND TABLE_NAME IN ('manufacturers', 'models')
GROUP BY TABLE_NAME
ORDER BY TABLE_NAME;
 
-- forein keys check
SELECT TABLE_NAME, COLUMN_NAME,  COUNT(*) AS pk_count
FROM information_schema.COLUMNS
WHERE TABLE_SCHEMA = DATABASE() AND COLUMN_KEY = 'MUL' AND TABLE_NAME IN ('manufacturers', 'models')
GROUP BY TABLE_NAME, COLUMN_NAME
ORDER BY TABLE_NAME, COLUMN_NAME;
 
-- data check
SELECT `man`.`manufacturer_id`, `man`.`name`, date(`man`.`established_on`), `m`.`model_id`, `m`.`name` 
FROM `manufacturer` AS `man` 
INNER JOIN `models` AS `m` ON `man`.`manufacturer_id` = `m`.`manufacturer_id`
ORDER BY `man`.`manufacturer_id`;