-- Many-To-Many Relationship
CREATE TABLE `students`(
  `student_id` INT PRIMARY KEY,
  `name` VARCHAR(50)
);

CREATE TABLE `exams`(
  `exam_id` INT PRIMARY KEY,
  `name` VARCHAR(50)
);

CREATE TABLE `students_exams`(
  `student_id` INT,
  `exam_id` INT,
  CONSTRAINT `pk_students_exams` PRIMARY KEY(`student_id`, `exam_id`),
  CONSTRAINT `fk_students_exams_students` FOREIGN KEY(`student_id`) REFERENCES `students`(`student_id`),
  CONSTRAINT `fk_students_exams_exams` FOREIGN KEY(`exam_id`) REFERENCES `exams`(`exam_id`)
);

INSERT INTO `students`(`student_id`, `name`)
VALUES
(1, 'Mila'),                                     
(2, 'Toni'),
(3, 'Ron');

INSERT INTO `exams`(`exam_id`, `name`)
VALUES 
(101, 'Spring MVC'),
(102, 'Neo4j'),
(103, 'Oracle 11g');

INSERT INTO `students_exams`(`student_id`, `exam_id`)
VALUES
(1, 101),
(1, 102),
(2, 101),
(3, 103),
(2, 102),
(2, 103);

-- check tables and column names
SELECT lower(table_name)
FROM information_schema.TABLES 
WHERE TABLE_SCHEMA = database() and lower(TABLE_NAME) = 'students';
SELECT lower(COLUMN_NAME) 
FROM information_schema.COLUMNS 
WHERE TABLE_SCHEMA = database() and lower(TABLE_NAME) = 'students';

SELECT lower(table_name)
FROM information_schema.TABLES 
WHERE TABLE_SCHEMA = database() and lower(TABLE_NAME) = 'exams';
SELECT lower(COLUMN_NAME) 
FROM information_schema.COLUMNS 
WHERE TABLE_SCHEMA = database() and lower(TABLE_NAME) = 'exams';

SELECT lower(table_name)
FROM information_schema.TABLES 
WHERE TABLE_SCHEMA = database() and lower(TABLE_NAME) = 'students_exams';
SELECT lower(COLUMN_NAME) 
FROM information_schema.COLUMNS 
WHERE TABLE_SCHEMA = database() and lower(TABLE_NAME) = 'students_exams';

-- tables PK check
SELECT COLUMN_NAME AS pk_count
FROM information_schema.COLUMNS
WHERE TABLE_SCHEMA = DATABASE() AND COLUMN_KEY = 'PRI' AND TABLE_NAME IN ('students');
   
SELECT COLUMN_NAME AS pk_count
FROM information_schema.COLUMNS
WHERE TABLE_SCHEMA = DATABASE() AND COLUMN_KEY = 'PRI' AND TABLE_NAME IN ('exams');
   
SELECT COLUMN_NAME AS pk_count
FROM information_schema.COLUMNS
WHERE TABLE_SCHEMA = DATABASE() AND COLUMN_KEY = 'PRI' AND TABLE_NAME IN ('students_exams');
   
-- fk_students_exams_students check
SELECT lower(TABLE_NAME) tn,lower(COLUMN_NAME) cn, lower(REFERENCED_TABLE_NAME) ref_tn,lower(REFERENCED_COLUMN_NAME) ref_cn
FROM INFORMATION_SCHEMA.KEY_COLUMN_USAGE
WHERE REFERENCED_TABLE_SCHEMA = database() AND lower(REFERENCED_COLUMN_NAME) = 'student_id' AND lower(REFERENCED_TABLE_NAME) = 'students';
  
-- fk_students_exams_exams check
SELECT lower(TABLE_NAME) tn,lower(COLUMN_NAME) cn, lower(REFERENCED_TABLE_NAME) ref_tn,lower(REFERENCED_COLUMN_NAME) ref_cn
FROM INFORMATION_SCHEMA.KEY_COLUMN_USAGE
WHERE REFERENCED_TABLE_SCHEMA = database() AND lower(REFERENCED_COLUMN_NAME) = 'exam_id' AND lower(REFERENCED_TABLE_NAME) = 'exams';
  
-- data check
SELECT * 
FROM`students` AS `s` 
INNER JOIN `students_exams` AS `se` ON `s`.`student_id` = `se`.`student_id` 
INNER JOIN `exams` AS `e` ON `e`.`exam_id` = `se`.`exam_id`
ORDER BY `s`.`student_id`, `e`.`exam_id`;