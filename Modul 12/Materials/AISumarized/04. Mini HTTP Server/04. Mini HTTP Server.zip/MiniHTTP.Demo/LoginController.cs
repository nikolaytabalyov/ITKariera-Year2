﻿using MiniHTTP.HTTP.Enums;
using MiniHTTP.HTTP.Requests;
using MiniHTTP.HTTP.Responses;
using MiniHTTP.WebServer.Results;

namespace MiniHTTP.Demo
{
    public class LoginController
    {
        public IHttpResponse Get(IHttpRequest request)
        {
            string content = File.ReadAllText("html/login.html"); ;

            return new HtmlResult(content, HttpResponseStatusCode.Ok);
        }

        public IHttpResponse Post(IHttpRequest request)
        {
            string content = string.Join("\n", request.FormData.Select(x => $"{x.Key}: {x.Value}").ToArray()); ;

            return new TextResult(content, HttpResponseStatusCode.Ok);
        }
    }
}
