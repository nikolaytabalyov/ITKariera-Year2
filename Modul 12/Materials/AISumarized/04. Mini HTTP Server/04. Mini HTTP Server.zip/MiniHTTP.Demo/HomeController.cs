﻿using MiniHTTP.HTTP.Enums;
using MiniHTTP.HTTP.Requests;
using MiniHTTP.HTTP.Responses;
using MiniHTTP.WebServer.Results;

namespace MiniHTTP.Demo
{
    public class HomeController
    {
        public IHttpResponse Get(IHttpRequest request)
        {
            string content = File.ReadAllText("html/index.html");

            return new HtmlResult(content, HttpResponseStatusCode.Ok);
        }

        public IHttpResponse Post(IHttpRequest request)
        {
            return new RedirectResult("/");
        }
    }
}
