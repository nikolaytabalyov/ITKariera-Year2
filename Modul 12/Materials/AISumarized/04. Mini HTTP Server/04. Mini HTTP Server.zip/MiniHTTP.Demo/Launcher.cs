﻿using MiniHTTP.WebServer;
using MiniHTTP.WebServer.Routing;

namespace MiniHTTP.Demo
{
    internal class Program
    {
        public static void Main(string[] args)
        {
            IServerRoutingTable serverRoutingTable = new ServerRoutingTable();

            // index.html
            serverRoutingTable.Add
            (
                HTTP.Enums.HttpRequestMethod.Get,
                "/",
                request => new HomeController().Get(request)
            );
            serverRoutingTable.Add
           (
               HTTP.Enums.HttpRequestMethod.Post,
               "/",
               request => new HomeController().Post(request)
           );

            // login.html
            serverRoutingTable.Add
            (
                HTTP.Enums.HttpRequestMethod.Get,
                "/login.html",
                request => new LoginController().Get(request)
            );
            serverRoutingTable.Add
            (
                HTTP.Enums.HttpRequestMethod.Post,
                "/login.html",
                request => new LoginController().Post(request)
            );

            Server server = new Server(8000, serverRoutingTable);
            server.Run();
        }
    }
}