﻿using System.Net.Sockets;
using System.Net;
using System.Text;

namespace ChatClient
{
	public class Program
	{
		static void Main(string[] args)
		{
			IPHostEntry ipHostInfo = Dns.GetHostEntry(Dns.GetHostName());
			IPAddress ipAddress = ipHostInfo.AddressList[0];
			IPEndPoint remoteEP = new IPEndPoint(ipAddress, 11000);

			Socket sender = new Socket(ipAddress.AddressFamily, SocketType.Stream, ProtocolType.Tcp);

			try
			{
				sender.Connect(remoteEP);
				Console.WriteLine("Socket connected to {0}", sender.RemoteEndPoint.ToString());

				while (true)
				{
					Console.Write(">");
					string messageString = Console.ReadLine();
					byte[] messageBytes = Encoding.ASCII.GetBytes(messageString + "<EOT>");

					int bytesSent = sender.Send(messageBytes);

					if (messageString == "exit")
					{
                        break;
                    }
				}

				sender.Shutdown(SocketShutdown.Both);
				sender.Close();
			}
			catch (Exception e)
			{
				Console.WriteLine(e.Message);
			}
		}
	}
}