﻿using System.Net.Sockets;
using System.Net;
using System.Text;

namespace ChatServer
{
	internal class Program
	{
		static void Main(string[] args)
		{
			IPHostEntry ipHostInfo = Dns.GetHostEntry(Dns.GetHostName());
			IPAddress ipAddress = ipHostInfo.AddressList[0];
			IPEndPoint localEndPoint = new IPEndPoint(ipAddress, 11000);

			Socket listener = new Socket(ipAddress.AddressFamily, SocketType.Stream, ProtocolType.Tcp);

			try
			{
				byte[] buffer = new byte[1024];

				listener.Bind(localEndPoint);
				listener.Listen(100);

				Socket handle = listener.Accept();

				while (true)
				{
                    string message = "";

                    while (true)
					{
						int messageSize = handle.Receive(buffer);
						message += Encoding.ASCII.GetString(buffer, 0, messageSize);

						if (message.Contains("<EOT>"))
						{
							message = message.Replace("<EOT>", "");
							break;
						}
					}

					Console.WriteLine("> " + message);

					if (message == "exit")
					{
						handle.Shutdown(SocketShutdown.Both);

						handle.Close();
						break;
					}
				}
			}
			catch (Exception ex)
			{
				Console.WriteLine(ex.Message);
			}

			Console.Clear();
			Console.WriteLine("Goodbye");
			Console.ReadKey(true);
		}
	}
}