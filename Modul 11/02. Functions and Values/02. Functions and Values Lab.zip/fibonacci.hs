-- Recursive function
fibonacci n =
    if n == 1 || n == 2 
    then 1
    else fib(n-2) + fib(n-1)

-- Main function
main = do

    -- Read single line as string
    line <- getLine

    -- Convert line to Integer number
    let n = read line :: Integer

    -- Execute recursive function and print the result
    putStrLn(show(fibonacci n))