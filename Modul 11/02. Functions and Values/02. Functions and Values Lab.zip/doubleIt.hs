-- Function that doubles it's parameter
doubleIt n = n * 2

-- Main function
main = do

    -- Read single line as string
    line <- getLine

    -- Convert to Integer
    let number = read line :: Integer

    -- Execute the function and print the result
    putStrLn (show(doubleIt number)) 