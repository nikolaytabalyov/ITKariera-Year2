-- version 1
biggestOf3 a b c = 
    if a > b
    then if a > c
         then a
         else c
    else if b > c
         then b
         else c

-- version 2
biggestOf3' a b c = max (max a b) c  

-- Main function
main = do

    -- Read three lines of string
    aStr <- getLine
    bStr <- getLine
    cStr <- getLine
    
    -- Convert lines to Integer numbers
    let a = read aStr :: Integer
    let b = read bStr :: Integer
    let c = read cStr :: Integer

    -- Execute both function versions and print the result
    putStrLn(show(biggestOf3 a b c))
    putStrLn(show(biggestOf3' a b c))