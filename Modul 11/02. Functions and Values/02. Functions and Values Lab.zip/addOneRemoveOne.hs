-- Increment
add1 n = n + 1

-- Decrement
remove1 n = n - 1

-- Composite function
compose f n = f n

-- Main function
main = do

    -- Read two lines as string
    func <- getLine
    number <- getLine

    -- Convert String to Integer
    let n = read number :: Integer

    -- Execute function add1 or remove1 and print the result
    if func == "add1"
    then putStrLn(show(execute add1 n))
    else putStrLn(show(execute remove1 n))