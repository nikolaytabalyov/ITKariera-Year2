-- version 1
evenNumber n =
    if (mod n 2) == 0
    then "True"
    else "False" 

-- version 2
evenNumber' n = 
    if n == 0 
    then "True"
    else if n == 1
         then "False"
         else evenNumber (n-2)

-- Main function
main = do

    -- Read single line as string
    line <- getLine

    -- Convert line to Integer number
    let number = read line :: Integer

    -- Execute both function versions and print the result
    putStrLn (evenNumber number) 
    putStrLn (evenNumber' number) 