-- Main function
main = do

    -- Read two lines as string 
    firstLine <- getLine
    secondLine <- getLine

    -- Convert string to Integer numbers
    let firstNum = read firstLine :: Integer
    let secondNum = read secondLine :: Integer
    
    -- Print multiplication
    putStrLn (show (firstNum * secondNum))