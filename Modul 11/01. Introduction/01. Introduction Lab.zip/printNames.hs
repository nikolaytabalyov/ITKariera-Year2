-- Main function
main = do

    -- Read first line as string 
    firstName <- getLine

    -- Read second line as string
    lastName <- getLine

    -- Concatenate and print
    putStrLn (firstName ++ " " ++ lastName)