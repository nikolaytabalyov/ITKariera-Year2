-- Main function
main = do

    -- Read single line as string
    line <- getLine

    -- Convert to string to float
    let radius = read line :: Float

    -- Calculate circle area
    let area = radius * radius * pi

    -- Print
    putStrLn (show (area))