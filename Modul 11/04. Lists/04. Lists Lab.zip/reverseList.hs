reverseList [] = []

reverseList (x:xs) = reverseList xs ++ [x]

main = do
    -- TODO: Implement main function