duplicate [] = []

duplicate (x:xs) = x:x:duplicate xs

main = do
    -- TODO: Implement main function