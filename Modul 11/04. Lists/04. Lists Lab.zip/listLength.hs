listLength [] = 0

listLength list = findLength 1 list

findLength length list = 
    if null list
    then (length - 1)
    else findLength (length + 1) (tail list)

main = do
    -- TODO: Implement main function