duplicate list = foldr (\ x xs -> x : x : xs) [] list

main = do
    -- TODO: Implement main function