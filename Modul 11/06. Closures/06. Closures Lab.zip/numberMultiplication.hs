f' a = (\ b -> a * b)

main = do
    -- TODO: Implement main function