log2 1 = 0

log2 n = 1 + log2 (n `div` 2)

main = do
    -- TODO: Implement main function